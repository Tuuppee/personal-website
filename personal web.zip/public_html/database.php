<?php
    $hostname = "localhost";
    $dbuser = "id21912399_tope";
    $dbPassword = "Frostbyte_23";
    $dbname = "id21912399_veterinary_db";
    $conn = mysqli_connect($hostname, $dbuser, $dbPassword, $dbname);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
?>